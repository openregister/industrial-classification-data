This correspondence between the Provisional CPC and ISIC Rev.3 reflects the link shown in the publication of the Provisional CPC (ESA/STAT/SER.M/77).
