Files:

README.txt      - this file
Intro note.txt  - introductory note
ISIC-USSIC.mdb  - MS Access database with correspondence table
ISIC-USSIC.csv  - text file containing correspondence table
SIC.csv         - text file containing the SIC codes and descriptions

The .csv files contain comma-separated values, and can for instance be imported
into Microsoft Excel (using "Import External Data" under the the "Data" menu in
Excel 2003) or other spreadsheet programs.