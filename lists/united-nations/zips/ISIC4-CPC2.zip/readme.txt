This ZIP archive includes the database version of the correspondence table between the International Standard Industrial Classification of All Economic Activities (ISIC), Rev.4 and the Central Product Classification (CPC) Version 2.

Note that waste products of the CPC (i.e. those in division 39) are not linked to an ISIC industry.

This file has been produced by the United Nations Statistics Division.


Initial publication: 31.12.2008

Update History:
- 31.12.2008	** The correspondence does not yet include divisions 45-47 of ISIC. These will be added later.
- 07.01.2009	Corrected ISIC4 link for CPC subclass 42997
