This correspondence table has been developed by the US Census Bureau.

Revision history:
14.08.17	Original release in the Classifications registry
