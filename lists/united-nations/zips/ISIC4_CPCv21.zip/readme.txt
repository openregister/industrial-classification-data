This ZIP archive includes the correspondence table between the International Standard Industrial Classification of All Economic Activities (ISIC) Rev.4 and the Central Product Classification (CPC) Version 2.1.

This file has been produced by the United Nations Statistics Division.


Initial publication: 19.08.2015

Update History:
- 19.08.2015	** The correspondence does not yet include divisions 45, 46 and 47 of ISIC. These will be added later.
