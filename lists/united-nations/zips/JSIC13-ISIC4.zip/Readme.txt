This correspondence table has been prepared by the Ministry of Internal Affairs and Communications of Japan.

Original release: 26.03.2014

Update history: None.
